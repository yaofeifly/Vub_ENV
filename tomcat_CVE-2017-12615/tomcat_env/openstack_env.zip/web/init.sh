#!/bin/bash

mv /tmp/flag.txt /usr/local/tomcat7/

cd /usr/local/tomcat7/bin

./startup.sh

sed -i "s/xxxxxx/$1/" /usr/local/tomcat7/flag.txt

