#!/bin/bash
apt-get update

apt-get install -y default-jdk

cp -rf ./bin/* /tmp

cd /tmp

tar -zxf apache-tomcat-7.0.76.tar.gz

mkdir /usr/local/tomcat7

cp -rf  apache-tomcat-7.0.76/* /usr/local/tomcat7/

cp -rf web.xml /usr/local/tomcat7/conf/

cd /usr/local/tomcat7/bin

./startup.sh

cp /tmp/index.jsp /usr/local/tomcat7/webapps/ROOT/





